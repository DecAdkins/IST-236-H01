import React, { useState } from 'react';
import { Text, View, TextInput, Button } from 'react-native';

const responses = [
  "Yes", "No", "Maybe", "Ask Again Later", "Definitely", "I Don't Know"
];

const MagicEightBall = () => {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("ASK A QUESTION.");

  const handleSubmit = () => {
    if (question.trim() === "") {
      setAnswer("ASK A QUESTION.");
    } else {
      const randomIndex = Math.floor(Math.random() * responses.length);
      setAnswer(responses[randomIndex]);
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text h1>Magic 8-Ball</Text>
      <View>
        <TextInput
          placeholder="ASK A QUESTION"
          value={question}
          onChangeText={setQuestion}
          style={{ padding: 10, width: 300, marginBottom: 10 }}
        />
        <Button title="SHAKE 8 BALL" onPress={handleSubmit} />
      </View>
      <Text>{answer}</Text>
    </View>
  );
};

export default MagicEightBall;