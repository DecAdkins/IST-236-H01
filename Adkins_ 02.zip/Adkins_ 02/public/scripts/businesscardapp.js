var BusinessCard = React.createClass({
    render: function () {
        console.log('Rendering business card');
        return (
            <div className="businesscard">
                <img src="/images/id_image.jpg" alt="picture of self"></img>
                <h1>Declan Adkins</h1>
                <h2><a href="mailto:dadkins2@hgtc.edu">dadkins2@hgtc.edu</a></h2>
                <h3><a href="tel:8439959195">(843) 995-9195</a></h3>
                <h3><a href="https://github.com/DecAdkins/IST-236-H01.git">https://github.com/DecAdkins/IST-236-H01.git</a></h3>
            </div>
        );
    }
});
ReactDOM.render(
    <BusinessCard />,
    document.getElementById('content')
);