import React from "react";
import { View, Text, FlatList, Image, StyleSheet } from "react-native";

const movies = [
  { title: "Tron: Legacy", poster: require("../../assets/images/tron.png"), rating: "4.6" },
  { title: "Whiplash", poster: require("../../assets/images/whiplash.png"), rating: "8.5" },
  { title: "Grind", poster: require("../../assets/images/grind.png"), rating: "5.9" },
  { title: "Chronicle", poster: require("../../assets/images/chronicle.png"), rating: "7.0" },
  { title: "The Amazing Spider-Man", poster: require("../../assets/images/spiderman.png"), rating: "6.9" },
  { title: "Oppenheimer", poster: require("../../assets/images/oppenheimer.png"), rating: "8.3" },
  { title: "Pulp Fiction", poster: require("../../assets/images/pulpfiction.png"), rating: "8.9" },
  { title: "Fight Club", poster: require("../../assets/images/fightclub.png"), rating: "8.8" },
  { title: "The Princess Bride", poster: require("../../assets/images/princessbride.png"), rating: "8.0" },
  { title: "The Truman Show", poster: require("../../assets/images/trumanshow.png"), rating: "8.2" }
];

const MovieItem = ({ title, poster, rating }) => (
  <View>
    <Image source={poster} style={{ width: 150, height: 300 }}/>
    <Text>{title}</Text>
    <Text>Rating: {rating}</Text>
  </View>
);

export default function App() {
  return (
    <View>
      <Text>Top 10 Movies</Text>
      <FlatList
        data={movies}
        renderItem={({ item }) => <MovieItem {...item} />}
        keyExtractor={(item) => item.title}
      />
    </View>
  );
}
